/*
    Módulo onde são chamadas todos os outros módulos utilizados no programa.
*/

#ifndef _HEADERS_H
#define _HEADERS_H

#include "hash.h"
#include "lista.h"

#endif